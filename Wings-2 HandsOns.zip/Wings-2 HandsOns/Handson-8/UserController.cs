using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using HealthCareService.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Extensions.Logging;

namespace HealthCareService.Controllers
{
    [Authorize]
    [ApiController]
    public class UserController : ControllerBase
    {
        public ApplicationDbContext _context;
        private readonly ILogger<UserController> _logger;
        public UserController(ApplicationDbContext context,ILogger<UserController> logger){
            _context=context;
            _logger = logger;
        }
        // POST api/user/register
       /* [HttpPost("register")]
        public IActionResult Register([FromBody] ApplicationUser user)
        {
            // Simulate user registration (e.g., saving to a database)
            _logger.LogInformation($"logging cart item: {user}");
            if (user == null)
            {
                return BadRequest("Invalid user data.");
            }
            _context.Add(user);

            // Here you would add logic to validate the input and save the user to a database
            // Simulating successful registration
            return Ok(new { Message = "User registered successfully", User = user });
        }
        */

              // POST api/user/register
        [AllowAnonymous]
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] ApplicationUser user)
        {
            if (user == null || string.IsNullOrWhiteSpace(user.user_name) || string.IsNullOrWhiteSpace(user.user_email))
            {
                return BadRequest("Invalid user data.");
            }

            _logger.LogInformation($"Attempting to register user: {JsonConvert.SerializeObject(user)}");

            // Check if user already exists
            var existingUser = _context.Users.FirstOrDefault(u => u.user_email == user.user_email);
            if (existingUser != null)
            {
                return Conflict("User already exists with this email.");
            }

            // Save the new user
            _context.Users.Add(user);
            await _context.SaveChangesAsync();  // Ensure changes are saved

            _logger.LogInformation($"User registered successfully: {user.user_email}");

            return CreatedAtAction(nameof(Register), new { id = user.user_email }, new { Message = "User registered successfully", User = user });
        }

         [AllowAnonymous]
        [HttpGet("database")]
        public void emptyDatabase(){
            _context.Database.EnsureDeleted();
        }

       
       

      
    }
}