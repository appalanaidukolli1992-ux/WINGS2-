using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using FastBite.Data;
using FastBite.Utility;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using FastBite.Models;

namespace FastBite.Areas.Admin.Controllers
{
   
    [Area("Admin")]
    public class UserController : Controller
    {
        public readonly ApplicationDbContext _db;
        private readonly ILogger<UserController> _logger;
        public UserController(ApplicationDbContext db,ILogger<UserController> logger){
            _db=db;
            _logger = logger;

        }
        public async Task<IActionResult> Index()
        {

        List<ApplicationUser> users = await _db.ApplicationUser.ToListAsync();
         _logger.LogInformation(users.Count().ToString());
        foreach (var user in users)
        {
            // Process each user
            Console.WriteLine($"Processing user: {user.Email}");
            _logger.LogInformation(user.Email);
            // Add your processing logic here
        }
            return View(await _db.ApplicationUser.ToListAsync());
        }
      
    }
}