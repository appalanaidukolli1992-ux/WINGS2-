import { Component, OnInit, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ApiService } from 'src/app/services/api.service';

import { Users } from '../../models/users.model';
import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})

export class ProfileComponent implements OnInit {

  editProfile = false;
  userId = -1;
  userDetails = new Users;

  editProfileForm: FormGroup;
  userImg = './../../assets/user.jpg';
  mobileErrMsg = 'You must enter a valid mobile number';
  emailErrMsg = 'You must enter a valid Email ID';
  locationErrMsg = 'You must enter the location';

  constructor(private dataService: DataService) { }

  ngOnInit() {

    // add necessary validators
    // userName should be disabled. it should not be edited
    this.userId = this.dataService.getUserId();
    this.editProfileForm = new FormGroup({
      userName: new FormControl({ value: '', disabled: true }),
      mobile: new FormControl('',
        [Validators.required,
        Validators.minLength(10),
        Validators.maxLength(10)]),
      email: new FormControl('',
        [Validators.required,
        Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$')]),
      location: new FormControl('', [Validators.required])
    });

    // get login status from service
    // get userId from service and assign it to userId property
    // get profile details and display it
    this.editProfileForm.markAllAsTouched();
    this.getProfileDetails();
    this.editProfileForm.controls['location'].setValue(null);
  }

  changeMyProfile() {

    // if successfully changed the profile it should display new details hiding the form
    if (this.editProfileForm.valid) {
      this.userDetails = new Users;
      this.userDetails.userId = this.userId;
      this.userDetails.username = localStorage.getItem('userName');
      this.userDetails.email = this.editProfileForm.value.email;
      this.userDetails.location = this.editProfileForm.value.location;
      this.userDetails.mobile = this.editProfileForm.value.mobile;
      this.dataService.updateProfile(this.userDetails).subscribe(
        (status: boolean) => {
          // Handle successful login
          console.log('Update status:', status);
          this.discardEdit();
        })
    }
  }
  editMyProfile() {

    // change editProfile property value appropriately
    this.editProfile = true;
    this.editProfileForm.controls['location'].setValue('testLocation');
    // Set invalid values to ensure the form is initially invalid
    //this.editProfileForm.controls['mobile'].setValue(''); // Invalid (required field)
    //this.editProfileForm.controls['email'].setValue(''); // Invalid (required field)
    //this.editProfileForm.controls['location'].setValue(''); // Invalid (required field)

    // Trigger validation to update the form state
    console.log(this.editProfileForm.dirty);
    this.editProfileForm.updateValueAndValidity();
  }

  discardEdit() {

    // change editProfile property value appropriately
    this.editProfile = false;
    this.editProfileForm.reset(); // Reset form to default values
    this.getProfileDetails(); // Re-fetch profile details to reflect any change
  }

  getProfileDetails() {

    // retrieve user details from service using userId
    this.dataService.getUserDetails(this.userId).subscribe({
      next: (user: Users) => {
        console.log(user);
        this.userDetails = user;
        localStorage.setItem('userName', this.userDetails.username);
        this.editProfileForm.get('userName')?.setValue(this.userDetails.username);
        this.editProfileForm.get('mobile')?.setValue(this.userDetails.mobile);
        this.editProfileForm.get('email')?.setValue(this.userDetails.email);
        this.editProfileForm.get('location')?.setValue(this.userDetails.location);
      },
      error: (error: any) => {
        // Handle the error by clearing form values
        this.editProfileForm.get('userName')?.setValue('');
        this.editProfileForm.get('mobile')?.setValue('');
        this.editProfileForm.get('email')?.setValue('');
        this.editProfileForm.get('location')?.setValue('');
      }
    });

  }

}
