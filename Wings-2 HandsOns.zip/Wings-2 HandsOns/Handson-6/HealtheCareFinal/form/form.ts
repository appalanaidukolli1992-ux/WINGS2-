import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { Patient } from '../../models/patient';
import { DataService } from '../../services/data.service';
// import * as alertify from 'alertify.js';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css'],
  providers: [DatePipe]
})
export class FormComponent implements OnInit {

  complexForm: FormGroup;
  patientDetails = new Patient;
  result;

  today: string;

  noRecordsFound = 'No patient records found in the list. Click on Register New Patient to add Patient details.';

  emptyFirstname = 'You must include a first name.';
  minlengthFirstname = 'Your first name must be at least 3 characters long.';
  maxlengthFirstname = 'Your first name cannot exceed 20 characters.';
  emptyLastname = 'You must include a last name.';
  minlengthLastname = 'Your last name must be at least 3 characters long.';
  maxlengthLastname = 'Your last name cannot exceed 20 characters.';
  noGender = 'You must select a gender.';
  noDob = 'You must select a valid date of birth.';
  noMobile = 'You must include mobile number.';
  numberMobile = 'You must enter a valid 10 digit mobile number.';
  maxlengthMobile = 'Your mobile number should not exceed 10 digits.';
  noEmail = 'You must include a valid email.';
  patternEmail = 'Pattern does not match.';

  ngOnInit() {
    this.today = this.datePipe.transform(Date.now(), 'yyyy-MM-dd');
  }

  constructor(fb: FormBuilder, private datePipe: DatePipe, private route: Router, private dataService: DataService) {
    this.complexForm = fb.group({
      'firstName': ['', [Validators.required,
      Validators.minLength(3),
      Validators.maxLength(20)]],
      'lastName': ['', [Validators.required,
      Validators.minLength(3),
      Validators.maxLength(20)]],
      'gender': ['', [Validators.required]],
      'dob': ['', [Validators.required]],
      'mobile': ['', [
        Validators.required,
        Validators.minLength(10),               // Field must be filled
        Validators.maxLength(10),             // Maximum length of 10 digits
        Validators.pattern(/^\d{10,}$/)
      ]],
      'email': ['', [
        Validators.required,
        Validators.email,
        Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
      ]],
      'description': ['']
    })
  }

  submitForm(value: any) {

    // assign new date object to reportedTime
    // should reister new patient using service
    // if added successfully should redirect to 'patientList' page
    if (this.complexForm.valid) {
      this.patientDetails = new Patient;
      this.patientDetails.firstName = this.complexForm.value.firstName;
      this.patientDetails.lastName = this.complexForm.value.lastName;
      this.patientDetails.gender = this.complexForm.value.gender;
      this.patientDetails.dob = this.complexForm.value.dob;
      this.patientDetails.email = this.complexForm.value.email;
      this.patientDetails.mobile = this.complexForm.value.mobile;
      this.patientDetails.description = this.complexForm.value.description;
      this.patientDetails.registeredTime = new Date();
      this.dataService.registerPatient(this.patientDetails).subscribe(resp => {
        this.route.navigate(['/patientList']);
      })
    }
  }

}
