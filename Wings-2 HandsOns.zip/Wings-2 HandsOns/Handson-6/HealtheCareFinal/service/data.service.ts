import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, observable, Observable, of, throwError } from 'rxjs';
import { Credentials } from '../models/credentials.model';
import { Users } from '../models/users.model';
import { Patient } from '../models/patient';
import { Appointment } from '../models/appointment';
import { ApiService } from './api.service';
import { catchError, map, tap } from 'rxjs/operators';


@Injectable()
export class DataService {

  isLoggedIn = false;
  isLogIn: BehaviorSubject<boolean>;
  constructor(private api: ApiService) {
    this.isLogIn = new BehaviorSubject<boolean>(false);
  }

  authenticateUser(username: string, password: string): Observable<boolean> {

    // store 'userId' from response as key name 'userId' to the localstorage
    // return true if user authenticated
    // return false if user not authenticated
    return this.api.checkLogin(username, password).pipe(
      map((resp: Credentials) => {
        if (resp) {
          localStorage.setItem('userId', resp.userId.toString());
          this.isLoggedIn = true;
          this.isLogIn.next(true);
          return true;  // User authenticated
        } else {
          this.isLoggedIn = false;
          this.isLogIn.next(false);
          return false;  // User not authenticated
        }
      })
    );
  }

  getAuthStatus(): Observable<boolean> {
   return this.isLogIn.asObservable();
  }
  doLogOut() {
    // remove the key 'userId' if exists
    localStorage.removeItem('userId');
    this.isLoggedIn = false;
    this.isLogIn.next(false);
  }

  getUserDetails(userId: number): Observable<Users> {

    // should return user details retrieved from api service
    return this.api.getUserDetails(userId).pipe(
      map((resp :Users) => {
        console.log(resp);
        // Assuming resp is the raw response object and needs to be mapped to Users
        // const user = new Users();
        // user.userId = resp.id;
        // user.username = resp.userDetails.username;
        // user.mobile = resp.mobile;
        // user.email = resp.email;
        // user.location = resp.location;
        return resp;
      }), catchError(this.handleError)
    );
  }

  updateProfile(userDetails): Observable<boolean> {
    return this.api.updateDetails(userDetails).pipe(
      map(resp => {
        return !!resp; // Assuming resp is truthy if the update was successful
      })
    );
  }

  registerPatient(patientDetails): Observable<any> {

    // should return response retrieved from ApiService
    // handle error
   return this.api.registerPatient(patientDetails).pipe(
      map(resp => {
        return resp;
      })
    );
  }

  getAllPatientsList(): Observable<any> {

    // should return all patients list retrieved from ApiService
    // handle error
    return this.api.getAllPatientsList().pipe(
      map(resp => {
        return resp;
      })
    );

  }

  getParticularPatient(id): Observable<any> {

    // should return particular patient details retrieved from ApiService

    // handle error
    return this.api.getParticularPatient(id).pipe(
      map(resp => {
        return resp;
      })
    );
  }

  getDiseasesList(): Observable<any> {

    // should return response retrieved from ApiService
    // handle error

    return this.api.getDiseasesList().pipe(
      map(resp => {
        return resp;
      })
    );
  }

  bookAppointment(appointmentDetails): Observable<any> {

    // should return response retrieved from ApiService
    // handle error

    return this.api.bookAppointment(appointmentDetails).pipe(
      map(resp => {
        return resp;
      })
    );
  }

  getAppointments(patientId): Observable<any> {

    // should return response retrieved from ApiService
    // handle error
    return this.api.getAppointments(patientId).pipe(
      map(resp => {
        return resp;
      })
    );
  }

  deleteAppointment(appointmentId): Observable<any> {

    // should return response retrieved from ApiService
    // handle error
    return this.api.deleteAppointment(appointmentId).pipe(
      map(resp => {
        return resp;
      })
    );
  }

  requestedAppointments(): Observable<any> {

    // should return response retrieved from ApiService

    // handle error
    return this.api.requestedAppointments().pipe(
      map(resp => {
        return resp;
      })
    );
  }

  getUserId(): number {

    // retrieve 'userId' from localstorage
    if(this.isLogIn.getValue())
     { if(localStorage.getItem('userId'))
        { return Number(localStorage.getItem('userId'));}
        else {
          return -1;
        }
      }
    else
     return -1;
  }

  private handleError(error: HttpErrorResponse) {
    // handle error
    return throwError(error.error);
  }

}


