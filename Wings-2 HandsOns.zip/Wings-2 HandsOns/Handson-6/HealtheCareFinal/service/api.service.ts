import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';

import { Credentials } from '../models/credentials.model';
import { Users } from '../models/users.model';
import { Patient } from '../models/patient';
import { Appointment } from '../models/appointment';
import { map, tap } from 'rxjs/operators';
import { catchError, retry } from 'rxjs/operators';

@Injectable()
export class ApiService {

  API_URL: String;
  AUTH_API_URL = '/auth/server/';

  constructor(private http: HttpClient) {
    this.API_URL = 'api';
  }

  public checkLogin(userName: string, password: string): Observable<Credentials> {

    return this.http.post<Credentials>(this.API_URL + this.AUTH_API_URL, { username: userName, password: password }).pipe(
      map((user: Credentials) => {
        console.log(user);

        // Process the response and map it to Credentials
        return {
          userId: user?.userId,
          username: user?.username,
          password: user?.password,
          isLoggedIn: !!user // if user is defined, isLoggedIn will be true
        } as Credentials;
      }),
      catchError((error: HttpErrorResponse) => this.handleError(error)) // Catch and handle the error
    );
  }

  public getUserDetails(userId: number): Observable<Users> {
    return this.http.get<Users>(`${this.API_URL}/users/${userId}`).pipe(
      catchError(this.handleError)
    );
  }

  public updateDetails(userDetails: Users): Observable<Users> {
    // should return user details if successfully updated the details
    // handle error
    return this.http.put<Users>(this.API_URL + '/users/' + userDetails.userId, userDetails).pipe(
      map(user => {
        console.log(user);

        // var useresp : Users ={
        //     userId: number;
        //     username: string;
        //     mobile: string;
        //     email: string;
        //     location: string;
        // }
        //localStorage.setItem('userName', user.userName);
        //localStorage.setItem('userid', user.id.toString());
        return user;
      }

      ),
      catchError(this.handleError)
    );
  }

  public registerPatient(patientDetails: any): Observable<any> {

    // should return response from server if patientDetails added successfully

    // handle error
    return this.http.post<Patient>(this.API_URL + '/allpatients', patientDetails).pipe(
      map(response => {
        console.log(response);
        return response;
      }

      ),
      catchError(this.handleError)
    );
  }

  public getAllPatientsList(): Observable<any> {

    // should return all patients from server
    // handle error
    return this.http.get<any>(this.API_URL + '/allpatients').pipe(
      map(response => {
        console.log(response);
        return response;
      }

      ),
      catchError(this.handleError)
    );
  }

  public getParticularPatient(id): Observable<any> {

    // should return particular patient details from server
    // handle error
    return this.http.get<any>(this.API_URL + '/allpatients/' + id).pipe(
      map(response => {
        console.log(response);
        return response;
      }

      ),
      catchError(this.handleError)
    );
  }

  public getDiseasesList(): Observable<any> {

    // should return diseases from server

    // handle error

    return this.http.get<any>(this.API_URL + '/diseases').pipe(
      map(response => {
        console.log(response);
        return response;
      }

      ),
      catchError(this.handleError)
    );
  }

  public bookAppointment(appointmentDetails: any): Observable<any> {

    // should return response from server if appointment booked successfully
    // // handle error
    // "patientId": 400,
    // "patientFirstName": "first",
    // "patientLastName": "name",
    // "disease": "Flu",
    // "priority": "Normal",
    // "tentativedate": "2019-02-21",
    // "registeredTime": "2019-02-19T10:30:06.127Z",
    return this.http.post<any>(this.API_URL + '/reqappointments', {
      patientId: appointmentDetails.patientId,
      patientFirstName: appointmentDetails.patientFirstName,
      patientLastName: appointmentDetails.patientLastName,
      disease: appointmentDetails.disease,
      priority: appointmentDetails.priority
      // tentativedate: appointmentDetails.tentativedate,
      // registeredTime: appointmentDetails.registeredTime,
    }).pipe(
      map(appointmentresp => {
        console.log(appointmentresp);
        return appointmentresp;
      }

      ),
      catchError(this.handleError)
    );

  }

  public requestedAppointments(): Observable<any> {

    // should return all requested appointments from server
    // handle error

    return this.http.get<any>(this.API_URL + '/reqappointments').pipe(
      map(response => {
        console.log(response);
        return response;
      }

      ),
      catchError(this.handleError)
    );
  }

  public getAppointments(patientId): Observable<any> {

    // should return appointments of particular patient from server
    // handle error
    return this.http.get<any>(this.API_URL + '/reqappointments?patientId=' + patientId).pipe(
      map(response => {
        console.log(response);
        return response;
      }

      ),
      catchError(this.handleError)
    );
  }

  public deleteAppointment(appointmentId): Observable<any> {

    // should delete the appointment
    // handle error
    return this.http.delete<any>(this.API_URL + '/reqappointments/' + appointmentId).pipe(
      map(response => {
        console.log(response);
        return response;
      }

      ),
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse) {
    const customErrorResponse = {
      message: "Incorrect username or password",
      status: error.status
    };

    // Return the custom error response
    return throwError({ error: customErrorResponse });
  }
}
