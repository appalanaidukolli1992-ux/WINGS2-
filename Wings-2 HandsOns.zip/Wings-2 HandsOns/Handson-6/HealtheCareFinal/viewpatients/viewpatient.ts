import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';
import { DataService } from '../../services/data.service';
import { Appointment } from '../../models/appointment';

@Component({
  selector: 'app-view-patient',
  templateUrl: './view-patient.component.html',
  styleUrls: ['./view-patient.component.css'],
  providers: [DatePipe]
})
export class ViewPatientComponent implements OnInit {
  patient: any;
  today: string;
  isBookAppointment = false;
  isScheduledAppointment = false;
  appointmentForm: FormGroup;
  appointmentDetails = new Appointment();
  diseases: any;
  ScheduledAppointmentResponse: any;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private datePipe: DatePipe,
    private dataService: DataService
  ) {
    this.today = this.datePipe.transform(Date.now(), 'yyyy-MM-dd');
  }

  ngOnInit(): void {
    this.appointmentForm = this.fb.group({
      selectDisease: ['', Validators.required],
      priority: ['', Validators.required],
      tentativeDate: ['', Validators.required],
    });

    this.dataService.getParticularPatient(this.route.snapshot.params['id']).subscribe(patient => {
      this.patient = patient;
    });
  }

  bookAppointment() {
    this.isBookAppointment = true;
    this.isScheduledAppointment = false;

    this.dataService.getDiseasesList().subscribe(diseases => {
      this.diseases = diseases;
    });
  }

  scheduledAppointment() {
    this.isScheduledAppointment = true;
    this.isBookAppointment = false;

    this.dataService.getAppointments(this.patient.id).subscribe(appointments => {
      this.ScheduledAppointmentResponse = appointments;
    });
  }

  scheduleAppointment() {
    if (this.appointmentForm.valid) {
      const appointment = {
        ...this.appointmentDetails,
        ...this.appointmentForm.value,
        patientId: this.patient.id,
      };

      this.dataService.bookAppointment(appointment).subscribe(() => {
        this.router.navigate(['/requested_appointments']);
      });
    }
  }

  cancelAppointment(id: number) {
    this.dataService.deleteAppointment(id).subscribe(() => {
      this.scheduledAppointment();
    });
  }
}
