

using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FastBite.Data;
using FastBite.Models;
using Microsoft.AspNetCore.Authorization;
using FastBite.Utility;

namespace FastBite.Areas.Admin.Controllers
{
   
    [Area("Admin")]
     public class CategoryController : Controller
    {
        private readonly ApplicationDbContext _db;

        public CategoryController(ApplicationDbContext db)
        {
            _db=db;
        }
        public ActionResult Index()
       {
           var category = _db.Category.ToList();
           return View(category);
       }
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
[ValidateAntiForgeryToken]
public async Task<IActionResult> Create([Bind("Id,Name")]Category category)
{
    if (ModelState.IsValid)
    {
        _db.Add(category);
        await _db.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }
    return View(category);
}
        
    }
}